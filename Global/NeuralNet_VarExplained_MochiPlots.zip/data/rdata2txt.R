
load("Pokusaev2019_S7_fitness_replicates.RData")

output.table <- all_variants[,c("fitness", "aa_seq")]

write.table(x = output.table,
            file = "S7.txt",
            quote = FALSE,
            row.names = FALSE,
            col.names = TRUE,
            sep = "\t")
